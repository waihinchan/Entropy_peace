/*
 utilities are used internally by ofxCv, and make it easier to write code that
 can work with OpenCv and openFrameworks data.
 
 useful functions from this file:
 - imitate and copy
 - toCv and toOf
 */

#pragma once

#include "opencv2/opencv.hpp"
#include "ofRectangle.h"
#include "ofTexture.h"
#include "ofPixels.h"
#include "ofVideoBaseTypes.h"
#include "ofVideoPlayer.h"
#include "ofVideoGrabber.h"
#include "ofPolyline.h"
#include "ofVectorMath.h"
#include "opencv2/imgproc/imgproc_c.h"
#include "opencv2/calib3d/calib3d_c.h"
namespace ofxCv {
	// these functions are for accessing Mat, ofPixels and ofImage consistently.
	// they're very important for imitate().
	
	// width, height
	template <class T> inline int getWidth(const T& src) {return src.getWidth();}
	template <class T> inline int getHeight(const T& src) {return src.getHeight();}
	inline int getWidth(const cv::Mat& src) {return src.cols;}
	inline int getHeight(const cv::Mat& src) {return src.rows;}
	template <class T> inline bool getAllocated(const T& src) {
		return getWidth(src) > 0 && getHeight(src) > 0;
	}
	
	// depth
    inline int getDepth(int cvImageType) {
        return CV_MAT_DEPTH(cvImageType);
    }

    inline int getDepth(const cv::Mat& mat) {
        return mat.depth();
    }

    inline int getDepth(const ofTexture& tex) {
        // avoid "texture not allocated" warning
        if(!tex.isAllocated()) {
            return CV_8U;
        }
        int type = tex.getTextureData().glInternalFormat;
        switch(type) {
            case GL_RGBA:
            case GL_RGB:
            case GL_LUMINANCE_ALPHA:
            case GL_LUMINANCE:
                return CV_8U;

#ifndef TARGET_OPENGLES
            case GL_RGBA8:
            case GL_RGB8:
            case GL_LUMINANCE8:
            case GL_LUMINANCE8_ALPHA8:
                return CV_8U;

            case GL_RGBA32F_ARB:
            case GL_RGB32F_ARB:
            case GL_LUMINANCE32F_ARB:
                return CV_32F;
#endif
            default: return 0;
        }
    }
    template <class T> inline int getDepth(const ofPixels_<T>& pixels) {
		switch(pixels.getBytesPerChannel()) {
			case 4: return CV_32F;
			case 2: return CV_16U;
			case 1: default: return CV_8U;
		}
	}
	template <> inline int getDepth(const ofPixels_<signed short>& pixels) {
		return CV_16S;
	}
	template <> inline int getDepth(const ofPixels_<signed char>& pixels) {
		return CV_8S;
	}
	template <class T> inline int getDepth(const ofBaseHasPixels_<T>& img) {
		return getDepth(img.getPixels());
	}
	
	// channels
	inline int getChannels(int cvImageType) {
		return CV_MAT_CN(cvImageType);
	}
	inline int getChannels(ofImageType imageType) {
		switch(imageType) {
			case OF_IMAGE_COLOR_ALPHA: return 4;
			case OF_IMAGE_COLOR: return 3;
			case OF_IMAGE_GRAYSCALE: default: return 1;
		}
	}
	inline int getChannels(const cv::Mat& mat) {
		return mat.channels();
	}
    inline int getChannels(const ofTexture& tex) {
        // avoid "texture not allocated" warning
        if(!tex.isAllocated()) {
            return GL_RGB;
        }
        int type = tex.getTextureData().glInternalFormat;
        switch(type) {
            case GL_RGBA: return 4;
            case GL_RGB: return 3;
            case GL_LUMINANCE_ALPHA: return 2;
            case GL_LUMINANCE: return 1;
                
#ifndef TARGET_OPENGLES
            case GL_RGBA8: return 4;
            case GL_RGB8: return 3;
            case GL_LUMINANCE8: return 1;
            case GL_LUMINANCE8_ALPHA8: return 2;
                
            case GL_RGBA32F_ARB: return 4;
            case GL_RGB32F_ARB: return 3;
            case GL_LUMINANCE32F_ARB: return 1;
#endif
            default: return 0;
        }
    }
	template <class T> inline int getChannels(const ofPixels_<T>& pixels) {
		return pixels.getNumChannels();
	}
	template <class T> inline int getChannels(const ofBaseHasPixels_<T>& img) {
		return getChannels(img.getPixels());
	}
	
	// image type
	inline int getCvImageType(int channels, int cvDepth = CV_8U) {
		return CV_MAKETYPE(cvDepth, channels);
	}
	inline int getCvImageType(ofImageType imageType, int cvDepth = CV_8U) {
		return CV_MAKETYPE(cvDepth, getChannels(imageType));
	}
	template <class T> inline int getCvImageType(const T& img) {
		return CV_MAKETYPE(getDepth(img), getChannels(img));
	}
	inline ofImageType getOfImageType(int cvImageType) {
		switch(getChannels(cvImageType)) {
			case 4: return OF_IMAGE_COLOR_ALPHA;
			case 3: return OF_IMAGE_COLOR;
			case 1: default: return OF_IMAGE_GRAYSCALE;
		}
	}
    inline int getGlImageType(int cvImageType) {
        int channels = getChannels(cvImageType);
        int depth = getDepth(cvImageType);
        switch(depth) {
            case CV_8U:
                switch(channels) {
                    case 1: return GL_LUMINANCE;
                    case 3: return GL_RGB;
                    case 4: return GL_RGBA;
                }
#ifndef TARGET_OPENGLES
            case CV_32F:
                switch(channels) {
                    case 1: return GL_LUMINANCE32F_ARB;
                    case 3: return GL_RGB32F;
                    case 4: return GL_RGBA32F;
                }
#endif
        }
        return 0;
    }
	
	// allocation
	// only happens when necessary
	template <class T> inline void allocate(T& img, int width, int height, int cvType) {
        if (!img.isAllocated() ||
            getWidth(img) != width ||
            getHeight(img) != height ||
            getCvImageType(img) != cvType)
        {
            img.allocate(width, height, getOfImageType(cvType));
        }
    }
    inline void allocate(ofTexture& img, int width, int height, int cvType) {
        if (!img.isAllocated() ||
            getWidth(img) != width ||
            getHeight(img) != height ||
            getCvImageType(img) != cvType)
        {
            img.allocate(width, height, getGlImageType(cvType));
        }
    }
	inline void allocate(cv::Mat& img, int width, int height, int cvType) {
        if (getWidth(img) != width ||
            getHeight(img) != height ||
            getCvImageType(img) != cvType) {
			img.create(height, width, cvType);
		}
	}
	// ofVideoPlayer/Grabber can't be allocated, so we assume we don't need to do anything
    inline void allocate(ofBaseVideoDraws & img, int width, int height, int cvType) {}
    inline void allocate(ofVideoPlayer & img, int width, int height, int cvType) {}
    inline void allocate(ofVideoGrabber & img, int width, int height, int cvType) {}

    inline void allocate(const ofBaseVideoDraws & img, int width, int height, int cvType) {}
    inline void allocate(const ofVideoPlayer & img, int width, int height, int cvType) {}
    inline void allocate(const ofVideoGrabber & img, int width, int height, int cvType) {}

	// imitate() is good for preparing buffers
	// it's like allocate(), but uses the size and type of the original as a reference
	// like allocate(), the image being allocated is the first argument	
	
	// this version copies size, but manually specifies mirror's image type
	template <class M, class O> void imitate(M& mirror, const O& original, int mirrorCvImageType) {
		int ow = getWidth(original), oh = getHeight(original);
		allocate(mirror, ow, oh, mirrorCvImageType);
	}

	// this version copies size and image type
	template <class M, class O> void imitate(M& mirror, const O& original) {
		imitate(mirror, original, getCvImageType(original));
	}

	// maximum possible values for that depth or matrix
	float getMaxVal(int cvDepth);
	float getMaxVal(const cv::Mat& mat);
	int getTargetChannelsFromCode(int conversionCode);
    
	// toCv functions
	// for conversion functions, the signature reveals the behavior:
	// 1       Type& argument // creates a shallow copy of the data
	// 2 const Type& argument // creates a deep copy of the data
	// 3       Type  argument // creates a deep copy of the data
	// style 1 is used when possible (for Mat conversion). style 2 is used when
	// dealing with a lot of data that can't/shouldn't be shallow copied. style 3
	// is used for small objects where the compiler can optimize the copying if
	// necessary. the reference is avoided to make inline toCv/toOf use easier.
	
    cv::Mat toCv(cv::Mat& mat);
    cv::Mat toCv(const cv::Mat& mat);

	template <class T> inline cv::Mat toCv(ofPixels_<T>& pix) {
		return cv::Mat(pix.getHeight(), pix.getWidth(), getCvImageType(pix), pix.getData(), 0);
	}

    template <class T> inline cv::Mat toCv(const ofPixels_<T>& pix) {
        return cv::Mat(pix.getHeight(), pix.getWidth(), getCvImageType(pix), const_cast<T*>(pix.getData()), 0).clone();
    }

	template <class T> inline cv::Mat toCv(ofBaseHasPixels_<T>& img) {
		return toCv(img.getPixels());
	}

    template <class T> inline cv::Mat toCv(const ofBaseHasPixels_<T>& img) {
        return toCv(img.getPixels());
    }

	cv::Mat toCv(ofMesh& mesh);
	cv::Point2f toCv(glm::vec2 vec);
	cv::Point3f toCv(glm::vec3 vec);
	cv::Rect toCv(ofRectangle rect);
	std::vector<cv::Point2f> toCv(const ofPolyline& polyline);
	std::vector<cv::Point2f> toCv(const std::vector<glm::vec2>& points);
	std::vector<cv::Point3f> toCv(const std::vector<glm::vec3>& points);
	cv::Scalar toCv(ofColor color);
	
	// cross-toolkit, cross-bitdepth copying
	template <class S, class D>
	void copy(S& src, D& dst, int dstDepth) {
		imitate(dst, src, getCvImageType(getChannels(src), dstDepth));
        cv::Mat srcMat = toCv(src);
        cv::Mat dstMat = toCv(dst);
		if(srcMat.type() == dstMat.type()) {
			srcMat.copyTo(dstMat);
		} else {
			double alpha = getMaxVal(dstMat) / getMaxVal(srcMat);
			srcMat.convertTo(dstMat, dstMat.depth(), alpha);
		}
	}

    template <class S, class D>
    void copy(const S& src, D& dst, int dstDepth) {
        imitate(dst, src, getCvImageType(getChannels(src), dstDepth));
        cv::Mat srcMat = toCv(src);
        cv::Mat dstMat = toCv(dst);
        if(srcMat.type() == dstMat.type()) {
            srcMat.copyTo(dstMat);
        } else {
            double alpha = getMaxVal(dstMat) / getMaxVal(srcMat);
            srcMat.convertTo(dstMat, dstMat.depth(), alpha);
        }
    }

	// most of the time you want the destination to be the same as the source. but
	// sometimes your destination is a different depth, and copy() will notice and
	// do the conversion for you.
	template <class S, class D>
	void copy(S& src, D& dst) {
		int dstDepth = 0;
		if(getAllocated(dst)) {
			dstDepth = getDepth(dst);
		} else {
			dstDepth = getDepth(src);
		}
		copy(src, dst, dstDepth);
	}

    template <class S, class D>
    void copy(const S& src, D& dst) {
        int dstDepth = 0;
        if(getAllocated(dst)) {
            dstDepth = getDepth(dst);
        } else {
            dstDepth = getDepth(src);
        }
        copy(src, dst, dstDepth);
    }

	// toOf functions
	glm::vec2 toOf(cv::Point2f point);
	glm::vec3 toOf(cv::Point3f point);
	ofRectangle toOf(cv::Rect rect);
	ofPolyline toOf(cv::RotatedRect rect);
	template <class T> inline ofPolyline toOf(const std::vector<cv::Point_<T>>& contour) {
		ofPolyline polyline;
		polyline.resize(contour.size());
        for(std::size_t i = 0; i < contour.size(); i++) {
			polyline[i].x = contour[i].x;
			polyline[i].y = contour[i].y;
		}
		polyline.close();
		return polyline;
	}
	template <class T>
	void toOf(cv::Mat mat, ofPixels_<T>& pixels) {
		pixels.setFromExternalPixels(mat.ptr<T>(), mat.cols, mat.rows, mat.channels());
	}
	template <class T>
	void toOf(cv::Mat mat, ofImage_<T>& img) {
		imitate(img, mat);
		toOf(mat, img.getPixels());
	}
}
