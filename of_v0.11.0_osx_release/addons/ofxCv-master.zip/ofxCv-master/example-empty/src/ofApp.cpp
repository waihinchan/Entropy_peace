#include "ofApp.h"

using namespace ofxCv;
using namespace cv;

void ofApp::setup() {
}

void ofApp::update() {
}

void ofApp::draw() {

}
